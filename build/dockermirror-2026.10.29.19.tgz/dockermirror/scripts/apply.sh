#!/bin/bash
# dockermirror - 将镜像源写入 /etc/docker/daemon.json（合并写入，保留其它字段）
# 安全策略：
#   1) daemon.json 解析失败 -> 绝不改写为 {}，保留原文件并退出，避免清掉 Unraid 的 Docker 网络配置
#   2) 仅当「运行中的 Docker」实际镜像源与配置不一致时才重启 Docker
#      - 配置没变 / 运行中已匹配 -> 完全不碰 Docker（零重启）
#      - Docker 未运行 -> 只写文件，启动后生效，不重启
#   3) 安装、卸载、开机钩子均不会无条件重启 Docker
set +e

plugin="dockermirror"
CONFIG_DIR="/boot/config/plugins/$plugin"
CONFIG="$CONFIG_DIR/$plugin.cfg"
DAEMON="/etc/docker/daemon.json"
RESTART="auto"
REMOVE=0

for arg in "$@"; do
  case "$arg" in
    --no-restart) RESTART="no" ;;
    --remove) REMOVE=1 ;;
  esac
done

MIRRORS=""
if [ "$REMOVE" -eq 0 ] && [ -f "$CONFIG" ]; then
  line=$(grep -E '^MIRRORS=' "$CONFIG" 2>/dev/null | head -1)
  MIRRORS="${line#MIRRORS=}"
  MIRRORS="${MIRRORS//\"/}"
fi

mkdir -p /etc/docker

if ! command -v python3 >/dev/null 2>&1; then
  echo "错误：未找到 python3，无法写入 daemon.json。"
  exit 1
fi

OUT=$(python3 - "$MIRRORS" "$DAEMON" "$REMOVE" <<'PYEOF'
import sys, json, os, subprocess
mirrors_raw, daemon_path, remove = sys.argv[1], sys.argv[2], sys.argv[3]
desired = []
if mirrors_raw:
    for m in mirrors_raw.split(','):
        m = m.strip()
        if m and m not in desired:
            desired.append(m)

# 读取当前 daemon.json（解析失败则保留原文件退出）
if os.path.exists(daemon_path):
    try:
        c = open(daemon_path).read().strip()
        data = json.loads(c) if c else {}
    except Exception as e:
        sys.stderr.write("daemon.json 解析失败，已保留原文件未改动: %s\n" % e)
        sys.exit(2)
else:
    data = {}

if remove:
    data.pop('registry-mirrors', None)
elif desired:
    data['registry-mirrors'] = desired
else:
    data.pop('registry-mirrors', None)

with open(daemon_path, 'w') as f:
    json.dump(data, f, indent=2)
    f.write('\n')

# 读取「运行中 Docker」当前的镜像源，用于判断是否需要重启
running = None
try:
    out = subprocess.check_output(
        ["docker", "info", "--format", "{{json .RegistryConfig.Mirrors}}"],
        stderr=subprocess.DEVNULL).decode().strip()
    running = json.loads(out) if out else []
except Exception:
    running = None  # Docker 未运行 / 不可用

print("desired=%s" % json.dumps(sorted(desired)))
print("running=%s" % ("UNAVAILABLE" if running is None else json.dumps(sorted(running))))
PYEOF
)
rc=$?
echo "$OUT"
if [ "$rc" -eq 2 ]; then
  echo "daemon.json 解析失败，未改动原文件，未重启 Docker。"
  exit 1
fi
if [ "$rc" -ne 0 ]; then
  echo "写入 daemon.json 失败"
  exit 1
fi

DESIRED=$(echo "$OUT" | grep '^desired=' | cut -d= -f2-)
RUNNING=$(echo "$OUT" | grep '^running=' | cut -d= -f2-)

if [ "$RESTART" = "no" ]; then
  echo "已按 --no-restart 跳过 Docker 重启。"
  exit 0
fi

if [ "$RUNNING" = "UNAVAILABLE" ]; then
  echo "Docker 当前未运行，仅写入配置（启动 Docker 后生效），不重启。"
  exit 0
fi

if [ "$RUNNING" != "$DESIRED" ]; then
  echo "运行中的 Docker 镜像源与配置不一致，重启 Docker 以应用..."
  /etc/rc.d/rc.docker restart
else
  echo "运行中的 Docker 已匹配配置，无需重启（零干扰）。"
fi
exit 0
