#!/bin/bash
# dockermirror - 将镜像源写入 /etc/docker/daemon.json（纯 bash 实现，无 python 依赖）
# 安全策略：
#   1) daemon.json 解析失败 -> 绝不改写为 {}，保留原文件并退出
#   2) 仅当「运行中的 Docker」实际镜像源与配置不一致时才重启 Docker
#   3) 安装、卸载、开机钩子均不会无条件重启 Docker
set +e

plugin="dockermirror"
CONFIG_DIR="/boot/config/plugins/$plugin"
CONFIG="$CONFIG_DIR/$plugin.cfg"
DAEMON="/etc/docker/daemon.json"
RESTART="auto"
REMOVE=0

for arg in "$@"; do
  case "$arg" in
    --no-restart) RESTART="no" ;;
    --remove) REMOVE=1 ;;
  esac
done

# 读取配置
MIRRORS=""
if [ "$REMOVE" -eq 0 ] && [ -f "$CONFIG" ]; then
  line=$(grep -E '^MIRRORS=' "$CONFIG" 2>/dev/null | head -1)
  MIRRORS="${line#MIRRORS=}"
  MIRRORS="${MIRRORS//\"/}"
fi

mkdir -p /etc/docker

# 检查 daemon.json 是否存在且有效
if [ ! -f "$DAEMON" ] || [ ! -s "$DAEMON" ]; then
  echo "{}" > "$DAEMON"
fi

# 备份原文件
cp "$DAEMON" "${DAEMON}.bak" 2>/dev/null

# 如果 MIRRORS 为空（恢复默认），删除 registry-mirrors 字段
if [ -z "$MIRRORS" ]; then
  # 用 sed 删除包含 registry-mirrors 的行
  if grep -q 'registry-mirrors' "$DAEMON"; then
    sed -i '/"registry-mirrors"/d' "$DAEMON"
    echo "已清除 registry-mirrors 配置"
  else
    echo "daemon.json 中无 registry-mirrors 配置"
  fi
else
  # 构建镜像源 JSON 数组
  MIRROR_JSON=""
  IFS=',' read -ra MIRROR_LIST <<< "$MIRRORS"
  for i in "${!MIRROR_LIST[@]}"; do
    m=$(echo "${MIRROR_LIST[$i]}" | xargs)
    if [ -n "$m" ]; then
      if [ $i -gt 0 ]; then
        MIRROR_JSON="${MIRROR_JSON},"
      fi
      MIRROR_JSON="${MIRROR_JSON}\"${m}\""
    fi
  done
  
  if [ -n "$MIRROR_JSON" ]; then
    # 检查是否已有 registry-mirrors 字段
    if grep -q 'registry-mirrors' "$DAEMON"; then
      sed -i '/"registry-mirrors"/d' "$DAEMON"
      sed -i "s/}$/  \"registry-mirrors\": [${MIRROR_JSON}],\n}/" "$DAEMON"
    else
      sed -i "s/}$/  \"registry-mirrors\": [${MIRROR_JSON}],\n}/" "$DAEMON"
    fi
    echo "已写入 registry-mirrors: [${MIRRORS}]"
  fi
fi

# 验证 JSON 格式（简单的括号匹配检查）
OPEN=$(grep -o '{' "$DAEMON" | wc -l)
CLOSE=$(grep -o '}' "$DAEMON" | wc -l)
if [ "$OPEN" -ne "$CLOSE" ]; then
  echo "警告：JSON 格式可能有问题，已恢复备份"
  cp "${DAEMON}.bak" "$DAEMON" 2>/dev/null
  exit 1
fi

# 检查运行中的 Docker 镜像源
RUNNING=""
if docker info >/dev/null 2>&1; then
  RUNNING=$(docker info --format '{{json .RegistryConfig.Mirrors}}' 2>/dev/null || echo "[]")
fi

# 构建期望的镜像源列表（排序后比较）
DESIRED=""
if [ -n "$MIRRORS" ]; then
  DESIRED=$(echo "$MIRRORS" | tr ',' '\n' | sort | tr '\n' ',')
fi

# 比较并决定是否重启
if [ "$RUNNING" = "[]" ] || [ -z "$RUNNING" ]; then
  if [ -n "$DESIRED" ]; then
    echo "Docker 未运行，仅写入配置"
  else
    echo "Docker 未运行且无配置，无需操作"
  fi
elif [ -z "$DESIRED" ]; then
  echo "当前 Docker 镜像源与配置不一致，重启 Docker..."
  /etc/rc.d/rc.docker restart
else
  RUNNING_SORTED=$(echo "$RUNNING" | tr -d '[]"' | tr ',' '\n' | sort | tr '\n' ',')
  if [ "$RUNNING_SORTED" != "$DESIRED" ]; then
    echo "运行中的 Docker 镜像源与配置不一致，重启 Docker..."
    /etc/rc.d/rc.docker restart
  else
    echo "运行中的 Docker 已匹配配置，无需重启（零干扰）。"
  fi
fi

rm -f "${DAEMON}.bak"
exit 0
