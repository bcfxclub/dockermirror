#!/bin/bash
# dockermirror - 将镜像源写入 /etc/docker/daemon.json（合并写入，保留其它字段）
set +e

plugin="dockermirror"
CONFIG_DIR="/boot/config/plugins/$plugin"
CONFIG="$CONFIG_DIR/$plugin.cfg"
DAEMON="/etc/docker/daemon.json"
RESTART="auto"
REMOVE=0

for arg in "$@"; do
  case "$arg" in
    --no-restart) RESTART="no" ;;
    --remove) REMOVE=1 ;;
  esac
done

MIRRORS=""
if [ "$REMOVE" -eq 0 ] && [ -f "$CONFIG" ]; then
  line=$(grep -E '^MIRRORS=' "$CONFIG" 2>/dev/null | head -1)
  MIRRORS="${line#MIRRORS=}"
  MIRRORS="${MIRRORS//\"/}"
fi

mkdir -p /etc/docker

if ! command -v python3 >/dev/null 2>&1; then
  echo "错误：未找到 python3，无法写入 daemon.json。"
  exit 1
fi

python3 - "$MIRRORS" "$DAEMON" <<'PYEOF'
import sys, json, os
mirrors_raw = sys.argv[1]
daemon_path = sys.argv[2]
mirrors = []
if mirrors_raw:
    for m in mirrors_raw.split(','):
        m = m.strip()
        if m and m not in mirrors:
            mirrors.append(m)
data = {}
if os.path.exists(daemon_path):
    try:
        with open(daemon_path) as f:
            c = f.read().strip()
            if c:
                data = json.loads(c)
    except Exception as e:
        sys.stderr.write("daemon.json 解析失败，已重置: %s\n" % e)
        data = {}
if mirrors:
    data['registry-mirrors'] = mirrors
else:
    data.pop('registry-mirrors', None)
with open(daemon_path, 'w') as f:
    json.dump(data, f, indent=2)
    f.write('\n')
print("registry-mirrors => %s" % (data.get('registry-mirrors', '（无）')))
PYEOF
rc=$?

if [ "$rc" -ne 0 ]; then
  echo "写入 daemon.json 失败"
  exit 1
fi

if [ "$RESTART" != "no" ]; then
  if docker info >/dev/null 2>&1; then
    echo "重启 Docker 以应用配置..."
    /etc/rc.d/rc.docker restart
  else
    echo "Docker 未运行，仅写入配置（启用 Docker 后生效）。"
  fi
fi
exit 0
