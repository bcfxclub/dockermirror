#!/bin/bash
# dockermirror - 将镜像源写入 /etc/docker/daemon.json（合并写入，保留其它字段）
# 安全策略：
#   1) daemon.json 解析失败 -> 绝不改写为 {}，保留原文件并退出，避免清掉 Unraid 的 Docker 网络配置
#   2) 仅当 registry-mirrors 真正发生变化时才重启 Docker，避免无谓的全量重启
set +e

plugin="dockermirror"
CONFIG_DIR="/boot/config/plugins/$plugin"
CONFIG="$CONFIG_DIR/$plugin.cfg"
DAEMON="/etc/docker/daemon.json"
RESTART="auto"
REMOVE=0

for arg in "$@"; do
  case "$arg" in
    --no-restart) RESTART="no" ;;
    --remove) REMOVE=1 ;;
  esac
done

MIRRORS=""
if [ "$REMOVE" -eq 0 ] && [ -f "$CONFIG" ]; then
  line=$(grep -E '^MIRRORS=' "$CONFIG" 2>/dev/null | head -1)
  MIRRORS="${line#MIRRORS=}"
  MIRRORS="${MIRRORS//\"/}"
fi

mkdir -p /etc/docker

if ! command -v python3 >/dev/null 2>&1; then
  echo "错误：未找到 python3，无法写入 daemon.json。"
  exit 1
fi

OUT=$(python3 - "$MIRRORS" "$DAEMON" "$REMOVE" <<'PYEOF'
import sys, json, os
mirrors_raw, daemon_path, remove = sys.argv[1], sys.argv[2], sys.argv[3]
mirrors = []
if mirrors_raw:
    for m in mirrors_raw.split(','):
        m = m.strip()
        if m and m not in mirrors:
            mirrors.append(m)
if os.path.exists(daemon_path):
    try:
        with open(daemon_path) as f:
            c = f.read().strip()
        data = json.loads(c) if c else {}
    except Exception as e:
        sys.stderr.write("daemon.json 解析失败，已保留原文件未改动: %s\n" % e)
        sys.exit(2)
else:
    data = {}
cur = data.get('registry-mirrors') or []
if remove:
    data.pop('registry-mirrors', None)
elif mirrors:
    data['registry-mirrors'] = mirrors
else:
    data.pop('registry-mirrors', None)
new = data.get('registry-mirrors') or []
changed = sorted(cur) != sorted(new)
with open(daemon_path, 'w') as f:
    json.dump(data, f, indent=2)
    f.write('\n')
print("registry-mirrors => %s" % (data.get('registry-mirrors', '（无）')))
print("CHANGED=%s" % ("1" if changed else "0"))
PYEOF
)
rc=$?
echo "$OUT"
if [ "$rc" -eq 2 ]; then
  echo "daemon.json 解析失败，未重启 Docker，也未改动原文件。"
  exit 1
fi
if [ "$rc" -ne 0 ]; then
  echo "写入 daemon.json 失败"
  exit 1
fi

CHANGED=$(echo "$OUT" | grep '^CHANGED=' | cut -d= -f2)
if [ "$CHANGED" = "1" ] && [ "$RESTART" != "no" ]; then
  if docker info >/dev/null 2>&1; then
    echo "镜像源已变化，重启 Docker 以应用..."
    /etc/rc.d/rc.docker restart
  else
    echo "Docker 未运行，仅写入配置（启用 Docker 后生效）。"
  fi
else
  echo "镜像源无变化，不重启 Docker。"
fi
exit 0
